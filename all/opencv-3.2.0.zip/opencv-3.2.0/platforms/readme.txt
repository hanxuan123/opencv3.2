This folder contains toolchains and additional files that are needed for cross compilation.
For more information see introduction tutorials for target platform in documentation:
http://docs.opencv.org/doc/tutorials/introduction/table_of_content_introduction/table_of_content_introduction.html#table-of-content-introduction
