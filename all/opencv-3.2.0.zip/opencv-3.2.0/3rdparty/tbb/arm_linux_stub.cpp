#include "tbb/tbb_misc.h"

namespace tbb {
namespace internal {

void affinity_helper::protect_affinity_mask() {}
affinity_helper::~affinity_helper() {}

}
}
